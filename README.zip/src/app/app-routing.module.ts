import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { HomeComponent } from './home/home.component';
import { FoHomeComponent } from './fo-home/fo-home.component';
import { FoEditProfileComponent } from './fo-edit-profile/fo-edit-profile.component';
import { FoVehicleRegistrationComponent } from './fo-vehicle-registration/fo-vehicle-registration.component';
import { FoChangePasswordComponent } from './fo-change-password/fo-change-password.component';
import { MediatorDashboardComponent } from './mediator-dashboard/mediator-dashboard.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { BookVehicleComponent } from './book-vehicle/book-vehicle.component';
import { SellcropsComponent } from './sell-crops/sell-crops.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { BuycropsComponent } from './buy-crops/buy-crops.component';
import { HeaderComponent } from './header/header.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent  },
  { path: 'register', component: RegistrationComponent  },
  { path: '', component: HomeComponent  },
  {path:'mediatorDashboard' , component:MediatorDashboardComponent},
  {path:'editprofile' , component:EditProfileComponent},
  {path:'bookvehicle' , component:BookVehicleComponent},
  {path:'sellcrops' , component:SellcropsComponent},
  {path:'changePassword',component:ChangePasswordComponent},
  {path:'buycrops' , component:BuycropsComponent},
  { 
    path: 'registers', 
    component: RegistrationComponent 
  },
  { 
    path: 'header', 
    component: HeaderComponent 
  },
  { 
    path: 'register/add', 
    component: RegistrationComponent 
  },
  { 
    path: 'registers/:username', 
    component: RegistrationComponent 
  },
  // { 
  //   path: '', 
  //   redirectTo: 'registers', 
  //   pathMatch: 'full'
  // }, 
  {
    path:'foHome' , 
    component : FoHomeComponent
},
{
    path: 'foHome/foeditprofile',
    component: FoEditProfileComponent
},
{
    path: 'foHome/fochangepassword',
    component: FoChangePasswordComponent
},
{
    path: 'foHome/fovehicleregistration',
    component : FoVehicleRegistrationComponent
}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
