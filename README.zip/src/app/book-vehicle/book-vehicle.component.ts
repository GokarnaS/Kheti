import { Component, OnInit } from '@angular/core';
import {FormBuilder,FormControl,FormGroup,Validators,ReactiveFormsModule,FormsModule}  from '@angular/forms';

@Component({
  selector: 'app-book-vehicle',
  templateUrl: './book-vehicle.component.html',
  styleUrls: ['./book-vehicle.component.css']
})
export class BookVehicleComponent implements OnInit {

  
  bookVehicle:FormGroup;
  
  
  constructor(private formbuilder:FormBuilder ){}
  ngOnInit(){
    this.bookVehicle= this.formbuilder.group({
      name:['',Validators.required],
      contactno:['',[Validators.required,Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
      vehicletype:[''],
      pickup : this.formbuilder.group({
         street:['',Validators.required],
         city:['',Validators.required],
         zip:['',[Validators.required, Validators.pattern('[0-9]{6}')]] }),
      drop : this.formbuilder.group({
          street:['',Validators.required],
          city:['',Validators.required],
          zip:['',[Validators.required, Validators.pattern('[0-9]{6}')]] }),  
      pickupdate:['',Validators.required] ,
      pickuptime:['',Validators.required]  
    });

  }
  get f() { return this.bookVehicle.controls; }
  get j() { return this.bookVehicle.get('pickup')['controls']; }
  get k() { return this.bookVehicle.get('drop')['controls']; }

  onSubmit() {
    
      if (this.bookVehicle.invalid) {
          return;
      }
      alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.bookVehicle.value, null, 4));
  }

 
 

}
