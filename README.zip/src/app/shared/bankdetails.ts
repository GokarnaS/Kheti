export class BankDetails{
    accountno : string;
    bankname : string;
    ifsccode : string;
    bankcontactno : string;
}