export class Register {
    firstname: string;
    lastname: string;
    username: string;
    email: string;
    password: string;
    cpassword: string;
    userType: string;
}