export class OfficeDetails {
    street : string;
    city : string;
    zipcode : string;
    contactno : string;
}