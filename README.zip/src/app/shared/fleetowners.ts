import { FleetOwner } from './fleetowner';
export const FLEETOWNERS : FleetOwner[] = [
    {
        firstname : "Abhishek",
        lastname : "Singh",
        username : "abhisheksingh",
        email : "abhisheksingh@gmail.com",
        password : "AbhishekSingh",
        aadhaar : "111122223333",
        officedetails : {
            city : "Bhopal",
            street : "MP Nagar",
            zipcode : "462013",
            contactno : "8989898989"
        },
        bankdetails : {
            accountno : "123412341234",
            bankname : "Axis",
            ifsccode : "axisas34343",
            bankcontactno : "8989898989"
        }
    },
    {
        firstname : "Rajni",
        lastname : "Kori",
        username : "rajnikori",
        email : "rajnikori@gmail.com",
        password : "RajniKori",
        aadhaar : "111122223333",
        officedetails : {
            city : "Bhopal",
            street : "MP Nagar",
            zipcode : "462013",
            contactno : "8989898989"
        },
        bankdetails : {
            accountno : "123412341234",
            bankname : "Axis",
            ifsccode : "axisas34343",
            bankcontactno : "8989898989"
        }
    },
    {
        firstname : "Rashi",
        lastname : "Jain",
        username : "rashijain",
        email : "rashijain@gmail.com",
        password : "RashiJain",
        aadhaar : "2222222222",
        officedetails : {
            city : "Guna",
            street : "gn Nagar",
            zipcode : "332013",
            contactno : "4564564564"
        },
        bankdetails : {
            accountno : "3232232323323",
            bankname : "HDFC",
            ifsccode : "hdfc34343",
            bankcontactno : "4564564564"
        }
    }
]