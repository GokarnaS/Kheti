import { BankDetails } from './bankdetails';
import { OfficeDetails } from './officedetails';
export class FleetOwner{
    firstname : string;
    lastname : string;
    username : string;
    email : string;
    password : string;
    aadhaar : string;
    officedetails : OfficeDetails;
    bankdetails : BankDetails
}