import { Component, OnInit } from '@angular/core';
import{FormBuilder,Validators, FormGroup} from '@angular/forms';

@Component({
  selector: 'app-sellcrops',
  templateUrl: './sell-crops.component.html',
  styleUrls: ['./sell-crops.component.css']
})
export class SellcropsComponent implements OnInit {
  
  sellCrop:FormGroup;
  submitted = false;
  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
       this.sellCrop = this.fb.group(
         {
            category:['',Validators.required],
            cropName:['',Validators.required],
            costPerUnit:['',Validators.required],
            quantity:['',Validators.required],
            nature:['',Validators.required],
            profilePhoto:['',Validators.required ]
      
         
         }
       );
  }
  onSubmit() {
    this.submitted = true;

    
    if (this.sellCrop.invalid) {
        return;
    }

   

    alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.sellCrop.value, null, 4));
}


}
