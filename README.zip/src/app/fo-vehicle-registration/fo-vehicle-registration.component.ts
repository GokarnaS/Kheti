import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-fo-vehicle-registration',
  templateUrl: './fo-vehicle-registration.component.html',
  styleUrls: ['./fo-vehicle-registration.component.css']
})
export class FoVehicleRegistrationComponent implements OnInit {

  licenseFile: File = null; //This Holds the License File Uploaded
  insuranceFile: File = null; //This Holds the Insurance File Uploaded
  constructor() { }

  ngOnInit(): void {
  }
  onRegister(f: NgForm) {
    console.log(f.value); //This Holds the Submitted Form Content
  }
  handleLicenseFile(files: FileList) {
    this.licenseFile = files.item(0);
  }
  handleInsuranceFile(files: FileList) {
    this.insuranceFile = files.item(0);
  }
}
