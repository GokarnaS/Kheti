import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FoVehicleRegistrationComponent } from './fo-vehicle-registration.component';

describe('FoVehicleRegistrationComponent', () => {
  let component: FoVehicleRegistrationComponent;
  let fixture: ComponentFixture<FoVehicleRegistrationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FoVehicleRegistrationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FoVehicleRegistrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
