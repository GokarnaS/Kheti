import { Component, OnInit } from '@angular/core';
import {FormBuilder,FormGroup,Validators} from '@angular/forms';
@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {
 editProfile : FormGroup;
 submitted =false;
  constructor(private fb:FormBuilder) { }

  ngOnInit(): void {
this.editProfile = this.fb.group(
  {
    adharCardNumber:['',[Validators.required,Validators.minLength(12)]],
    streetName:  ['', Validators.required],
    city:  ['' , Validators.required],
    zipCode: ['' ,[Validators.required, Validators.pattern('[0-9]{6}')]],
    bankAccountNumber : ['',Validators.required],
    bankName: ['',Validators.required],
    ifscCode:['',Validators.required],
    regPhoneNumber:['',[Validators.required,Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
    cardNumber:['',Validators.required],
    nameOnCard:['',Validators.required],
    cvv:['',[Validators.required, Validators.minLength(3)]],
    expMonth:['',Validators.required],
    expYear:['',Validators.required]
    
  }
);
}
onSubmit() {
    this.submitted = true;

    if (this.editProfile.invalid) {
        return;
    }
    alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.editProfile.value, null, 4));
}



}
