import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { AbstractControl } from '@angular/forms';
import { PasswordValidator } from '../Password.Validator';
import { Router } from '@angular/router';
import { Register } from '../shared/register';
import { RegisterService } from '../services/register.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent {

  
  get firstName(){
    return this.registrationForm.get('first_name');
  }
  get last_name(){
    return this.registrationForm.get('last_name');
  }
  get userName(){
    return this.registrationForm.get('userName');
  }
  get email(){
    return this.registrationForm.get('email');
  }
  get Password(){
    return this.registrationForm.get('password');
  }
  get confirmPassword(){
    return this.registrationForm.get('confirmPassword');
  }
  get termsConditions(){
    return this.registrationForm.get('confirmPassword');
  }
  get userType(){
    return this.registrationForm.get('userType');
  }

  constructor(private fb: FormBuilder,
    private router: Router,
    private registerService: RegisterService,
    private location: Location){}

  registrationForm = this.fb.group({
  
      first_name: ['',[Validators.required, Validators.minLength(2)]],
      last_name: ['',[Validators.required, Validators.minLength(2)]],
  
    userName:['',[Validators.required, Validators.minLength(6)]],
    password:['',[Validators.required, Validators.minLength(8)]],
    confirmPassword: ['',[Validators.required, Validators.minLength(8)]],
    userType:['',Validators.required],
    email:['',[Validators.required, Validators.email]],
    termsConditions:['', Validators.requiredTrue],
  }, {validator: PasswordValidator});

 

  btnClick= function () {
    this.router.navigateByUrl('/login');
  };


 
  register = new Register();
  submitted = false;
 
 
 
  newRegister(): void {
    this.submitted = false;
    this.register = new Register();
  }
 addRegister() {
   this.submitted = true;
   this.save();
   this.router.navigateByUrl('/login');

   alert(this.registrationForm.get('userName').value +" , You are registered Successfully. ")
 }
 
  goBack(): void {
    this.location.back();
  }
 
  private save(): void {
    this.registerService.addRegister(this.register)
        .subscribe();
  }

  


//  registrationForm = new FormGroup({
//    fullName: new FormGroup({
//     first_name: new FormControl(''),
//     last_name : new FormControl('')
//    }),
//    userName: new FormControl('Vishwas'),
//    password: new FormControl(''),
//    confirmPassword: new FormControl('')

//  });

//  loadAPIData(){
//    this.registrationForm.patchValue({
//      fullName:{
//        first_name:'chetna',
//        last_name:'Ganatra'
//      },
//      password:'1234',
//      confirmPassword:'1234'
//    });
//  }

 
}
