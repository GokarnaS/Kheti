import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(private fb: FormBuilder,private router: Router) { }

  ngOnInit() {
  }
  myForm = this.fb.group({

  });

  btnClick= function () {
    this.router.navigateByUrl('/login');
  };

  registerDirect(){
    this.router.navigateByUrl('/register');
     
   };
   
   loginDirect(){
     this.router.navigateByUrl('/login');
     
    };

}
