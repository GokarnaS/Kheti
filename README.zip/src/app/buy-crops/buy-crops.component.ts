import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buycrops',
  templateUrl: './buy-crops.component.html',
  styleUrls: ['./buy-crops.component.css']
})
export class BuycropsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
