import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FoChangePasswordComponent } from './fo-change-password.component';

describe('FoChangePasswordComponent', () => {
  let component: FoChangePasswordComponent;
  let fixture: ComponentFixture<FoChangePasswordComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FoChangePasswordComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FoChangePasswordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
