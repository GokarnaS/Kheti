import { FleetOwner } from './../shared/fleetowner';
import { FleetownerService } from './../services/fleetowner.service';
import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';


@Component({
  selector: 'app-fo-change-password',
  templateUrl: './fo-change-password.component.html',
  styleUrls: ['./fo-change-password.component.css']
})
export class FoChangePasswordComponent implements OnInit {

  editPasswordForm : FormGroup;
  fleetowner : FleetOwner;
  fleetowners : FleetOwner[];

  constructor(private formBuilder : FormBuilder,
    private fleetOwnerService : FleetownerService) {
    this.createForm();
   }

   createForm(){
     this.editPasswordForm = this.formBuilder.group({
       email : '',
       password : '',
       confirmPassword : ''
     })
   }

   onSubmit(){
    // this.fleetowner =  this.fleetOwnerService.getAllFleetOwners()
    // .subscribe((fleetowners)=>fleetowners.filter((fleetowner)=>(this.editPasswordForm.get('email').value===fleetowner.email)))[0];

     //console.log(this.editPasswordForm.get('email').value);
    
    this.fleetOwnerService.getAllFleetOwners().subscribe((fleetowners)=>this.fleetowners=fleetowners);
    
    //console.log('type of fleet owners array is '+typeof(this.fleetowners));

    //console.log(this.fleetowners);

    for(let i of this.fleetowners){
      if(i.email === this.editPasswordForm.get('email').value){
        this.fleetowner = i;
        //console.log("inside for "+ i)
        this.fleetOwnerService.deleteItemInArray(i);
        break;
        
      }
    }
    //console.log("The retrieved fleetowner from email is "+this.fleetowner.firstname, this.fleetowner.lastname);

    this.fleetowner.password = this.editPasswordForm.get('password').value;
    this.fleetOwnerService.pushNewItemInArray(this.fleetowner);


   }

  ngOnInit() {
  }

}
