import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
@Component({
  selector: 'app-mediator-dashboard',
  templateUrl: './mediator-dashboard.component.html',
  styleUrls: ['./mediator-dashboard.component.css']
})
export class MediatorDashboardComponent implements OnInit {

  constructor(private router:Router) { }
 
  onEditClick()
  {
    this.router.navigate(['/editprofile']);
  }
  onBookVehicleClick(){
    this.router.navigate(['/bookvehicle']);
  }
  onChangePasswordClick(){
    this.router.navigate(['/changePassword']);

  }
  ngOnInit(): void {
  }

}
