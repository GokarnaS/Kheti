import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fo-home',
  templateUrl: './fo-home.component.html',
  styleUrls: ['./fo-home.component.css']
})
export class FoHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
