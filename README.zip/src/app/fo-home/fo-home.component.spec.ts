import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FoHomeComponent } from './fo-home.component';

describe('FoHomeComponent', () => {
  let component: FoHomeComponent;
  let fixture: ComponentFixture<FoHomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FoHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FoHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
