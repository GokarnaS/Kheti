import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ReactiveFormsModule } from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { RegistrationComponent } from './registration/registration.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule }    from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { FoHomeComponent } from './fo-home/fo-home.component';
import { FoEditProfileComponent } from './fo-edit-profile/fo-edit-profile.component';
import { FoVehicleRegistrationComponent } from './fo-vehicle-registration/fo-vehicle-registration.component';
import { FoChangePasswordComponent } from './fo-change-password/fo-change-password.component';
import { MediatorDashboardComponent } from './mediator-dashboard/mediator-dashboard.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { BuycropsComponent } from './buy-crops/buy-crops.component';
import { BookVehicleComponent } from './book-vehicle/book-vehicle.component';
import { SellcropsComponent } from './sell-crops/sell-crops.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    RegistrationComponent,
    FoHomeComponent,
    FoEditProfileComponent,
    FoVehicleRegistrationComponent,
    FoChangePasswordComponent,
    MediatorDashboardComponent,
    EditProfileComponent,
    ChangePasswordComponent,
    BuycropsComponent,
    BookVehicleComponent,
    SellcropsComponent,
    HeaderComponent,
    FooterComponent
    ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
