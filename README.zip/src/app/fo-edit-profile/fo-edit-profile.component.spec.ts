import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FoEditProfileComponent } from './fo-edit-profile.component';

describe('FoEditProfileComponent', () => {
  let component: FoEditProfileComponent;
  let fixture: ComponentFixture<FoEditProfileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FoEditProfileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FoEditProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
