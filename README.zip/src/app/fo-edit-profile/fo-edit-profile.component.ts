import { FleetownerService } from './../services/fleetowner.service';
import { FLEETOWNERS } from './../shared/fleetowners';
import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';


@Component({
  selector: 'app-fo-edit-profile',
  templateUrl: './fo-edit-profile.component.html',
  styleUrls: ['./fo-edit-profile.component.css']
})
export class FoEditProfileComponent implements OnInit {

  editform : FormGroup;


  foaadhaar : string;
  fostreet : string;
  focity : string;
  fozipcode : string;
  focontactno : string;
  foaccountno : string;
  fobankname : string;
  foifsccode : string;
  fobankcontactno : string;

  constructor(private formbuilder : FormBuilder, private fleetOwnerService :FleetownerService) {
    this.fleetOwnerService.getCurrentFleetOwner().subscribe((fleetowner)=> {
      this.foaadhaar = fleetowner.aadhaar;
      this.fostreet = fleetowner.officedetails.street;
      this.focity = fleetowner.officedetails.city;
      this.fozipcode = fleetowner.officedetails.zipcode;
      this.focontactno = fleetowner.officedetails.contactno;
      this.foaccountno = fleetowner.bankdetails.accountno;
      this.fobankname = fleetowner.bankdetails.bankname;
      this.foifsccode = fleetowner.bankdetails.ifsccode;
      this.fobankcontactno = fleetowner.bankdetails.bankcontactno;
    });
    
    this.createForm();
    console.log('FleetOwners are  as follows: ',FLEETOWNERS);
    
   }
  ngOnInit() {
  }

  createForm(){
    this.editform = this.formbuilder.group({
      aadhaar : [this.foaadhaar],
      street : [this.fostreet],
      city : [this.focity],
      zipcode : [this.fozipcode],
      contactno : [this.focontactno],
      accountno : [this.foaccountno],
      bankname : [this.fobankname],
      ifsccode : [this.foifsccode],
      bankcontactno : [this.fobankcontactno]
    })
  }

}
