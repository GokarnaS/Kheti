import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private fb: FormBuilder,private router: Router){}

  ngOnInit() {
  }
  get userName(){
    return this.loginForm.get('userName');
  }
  get Password(){
    return this.loginForm.get('password');
  }
  get userType(){
    return this.loginForm.get('userType');
  }

  loginForm = this.fb.group({

    userName:['',[Validators.required, Validators.minLength(6)]],
    password:['',[Validators.required, Validators.minLength(8)]],
    userType:['',Validators.required],
  });

   myForm = this.fb.group({

  });

  
  afterLogin(){
    if(this.userType.value == "Mediator")
    {
      this.router.navigateByUrl('/mediatorDashboard');
    }
     if(this.userType.value == "Fleet Owner")
    {
      this.router.navigateByUrl('/foHome');
    }
  } 
}
