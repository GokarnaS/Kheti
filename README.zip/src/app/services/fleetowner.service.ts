import { Injectable } from '@angular/core';
import { FLEETOWNERS } from './../shared/fleetowners';
import { Observable, of } from 'rxjs';
import { FleetOwner } from '../shared/fleetowner';



@Injectable({
  providedIn: 'root'
})
export class FleetownerService {

  fleetowners : FleetOwner[];
  constructor() { 
    this.fleetowners = FLEETOWNERS;
  }

  getCurrentFleetOwner() : Observable<FleetOwner>{
    return of(this.fleetowners[0]);
  }

  getAllFleetOwners() : Observable<FleetOwner[]>{
    return of(this.fleetowners);
  }

  deleteItemInArray(element : FleetOwner){
    this.fleetowners = this.fleetowners.filter(fleetowner => fleetowner.username != element.username);
    console.log("after deletion : '");
    console.log(this.fleetowners);
  }

  pushNewItemInArray(element : FleetOwner){
    this.fleetowners.push(element);
    console.log("After updating password: ");
    console.log( this.fleetowners);
  }

  setCurrentFleetOwner(){
    //session management here for setting up the current logged in fleet owner
  }
}
