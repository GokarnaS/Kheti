import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Register } from '../shared/register';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class RegisterService {
  private registersUrl = 'http://localhost:8080/api/registers';  // URL to web api

  constructor(private http: HttpClient) { }

  
  
  addRegister (register: Register): Observable<Register> {
    return this.http.post<Register>(this.registersUrl, register, httpOptions);
  }
  
}

 
