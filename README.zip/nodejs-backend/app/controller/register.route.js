module.exports = function(app) {
 
    const customers = require('../controller/register.controller.js');
 
    // Create a new Customer
    app.post('/api/registers', customers.create);
 
   
}