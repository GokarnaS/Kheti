const db = require('../config/db.config.js');
const Register = db.registers;
 
exports.create = (req, res) => {  
  // Save to MySQL database
  let register = req.body;
  Register.create(register).then(result => {    
    res.json(result);
  });
};

