module.exports = (sequelize, Sequelize) => {
    const Register = sequelize.define('register', {
      firstname: {
      type: Sequelize.STRING
      },
      lastname: {
      type: Sequelize.STRING
      },
      username: {
      type: Sequelize.STRING
      },
      email: {
      type: Sequelize.STRING,
      primaryKey: true
      },
      password: {
        type: Sequelize.STRING
      },
      cpassword: {
        type: Sequelize.STRING
      },
      userType: {
        type: Sequelize.STRING
      },
    },
    {       
      timestamps: false
    });
    
    return Register;
  }